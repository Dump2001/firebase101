// Initialize Cloud Firestore through Firebase
import { initializeApp } from "firebase/app";
import { getFirestore } from "firebase/firestore";
const firebaseApp = initializeApp({
  apiKey: "AIzaSyDp5xUEdrRLOolXACOOPCzZU62Mt-wdic8",
  authDomain: "database101-d9195.firebaseapp.com",
  projectId: "database101-d9195",
  storageBucket: "database101-d9195.appspot.com",
  messagingSenderId: "893132806303",
  appId: "1:893132806303:web:bc908d317573ff66a8aaaa",
  measurementId: "G-LRKNH0X7GF",
});

const db = getFirestore(firebaseApp);
export default db;
